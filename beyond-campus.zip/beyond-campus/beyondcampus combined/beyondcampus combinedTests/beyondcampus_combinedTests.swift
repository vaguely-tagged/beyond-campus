//
//  beyondcampus_combinedTests.swift
//  beyondcampus combinedTests
//
//  Created by Sophia Miranda on 4/1/25.
//

import Testing
@testable import beyondcampus_combined

struct beyondcampus_combinedTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
