//
//  beyondcampus_combinedApp.swift
//  beyondcampus combined
//
//  Created by Sophia Miranda on 4/1/25.
//

import SwiftUI

@main
struct beyondcampus_combinedApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
