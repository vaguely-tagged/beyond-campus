//
//  Senior_Design_AppApp.swift
//  Senior Design App
//
//  Created by Sophia Miranda on 2/5/25.
//

import SwiftUI

@main
struct Senior_Design_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
