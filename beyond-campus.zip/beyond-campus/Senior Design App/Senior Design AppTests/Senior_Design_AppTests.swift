//
//  Senior_Design_AppTests.swift
//  Senior Design AppTests
//
//  Created by Sophia Miranda on 2/5/25.
//

import Testing
@testable import Senior_Design_App

struct Senior_Design_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
