//
//  Senior_DesignApp.swift
//  Senior Design
//
//  Created by Sophia Miranda on 2/5/25.
//

import SwiftUI

@main
struct Senior_DesignApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
