import SwiftUI
import WebKit

// Create a WebView struct to represent WKWebView
struct WebView: UIViewRepresentable {
    let url: URL
    
    // Create and configure WKWebView
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        
        // Set up navigation delegate
        webView.navigationDelegate = context.coordinator
        
        let request = URLRequest(url: url)
        webView.load(request)
        
        return webView
    }
    
    // Update the view (no updates needed for this case)
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // Nothing to update for this simple case
    }
    
    // Create a Coordinator to handle navigation and delegate methods
    func makeCoordinator() -> WebViewCoordinator {
        return WebViewCoordinator()
    }
}

// Create a custom Coordinator to handle WKNavigationDelegate
class WebViewCoordinator: NSObject, WKNavigationDelegate {
    
    // Handle certificate challenges (self-signed certificates)
    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        
        // Check if the challenge is related to server trust (certificate validation)
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
            // Allow self-signed certificates by trusting the server's certificate
            let credential = URLCredential(trust: challenge.protectionSpace.serverTrust!)
            completionHandler(.useCredential, credential)
        } else {
            // For other types of challenges, do the default handling
            completionHandler(.performDefaultHandling, nil)
        }
    }
}

struct ContentView: View {
    var body: some View {
        // Full-screen WebView
        WebView(url: URL(string: "https://192.168.0.190")!)
            .edgesIgnoringSafeArea(.all) // Make the WebView full screen
    }
}

#Preview {
    ContentView()
}
