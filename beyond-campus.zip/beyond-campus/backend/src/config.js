module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: process.env.MYSQL_PASSWORD,
  DB: "db_ss",
  connectTimeout: 60000,
};
